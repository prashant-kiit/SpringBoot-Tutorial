//package com.example.demo2.security;
//
////import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
////import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
//
////WebSecurityConfigureAdapter is now deprecated
//
////@Configuration
////@EnableWebSecurity 
////class WebServerSecurityConfiguration extends WebSecurityConfigureAdapter{
////	
////}
