package com.example.demo2.repository;

public interface SaleRepoOther {

}
