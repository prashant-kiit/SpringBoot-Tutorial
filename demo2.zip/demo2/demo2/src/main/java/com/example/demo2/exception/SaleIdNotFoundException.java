package com.example.demo2.exception;

public class SaleIdNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SaleIdNotFoundException(String message) {
		super(message);

	}

}
